import os,subprocess,base64,json,sys
from pathlib import Path
out=Path('/tmp/nexora-fixture-evidence-004');env=os.environ.copy();env.update({'PATH':'/tmp/nexora-governed-toolchain/bin:'+env['PATH'],'APP_ENV':'testing','APP_KEY':'base64:'+base64.b64encode(os.urandom(32)).decode(),'DB_CONNECTION':'sqlite','DB_DATABASE':':memory:','APP_URL':'https://nexora.test','APP_DEBUG':'false','NEXORA_INSTALLER_BYPASS':'true'})
name=sys.argv[1];cmd=['php','-d','memory_limit=512M','vendor/bin/phpunit','--display-warnings','--fail-on-warning','--log-junit',str(out/(name+'.xml'))]
if name=='targeted':cmd+=['--filter','TargetProcessCaptureTest|BrowserSessionBootstrapBehaviourTest|N100Rc20FinalClosureIntegrityArchitectureTest']
p=subprocess.run(cmd,cwd='/tmp/nexora-full-fixture-004',env=env,capture_output=True,text=True,timeout=360)
(out/(name+'.txt')).write_text(p.stdout+p.stderr);(out/(name+'-exit.json')).write_text(json.dumps({'exit_code':p.returncode,'source_sha':'99274cedd8117f149da5f0e56ce3ab1312eb1833','candidate_lock_sha256':'11cf1db05f0abc833e3e5ce480d796e82360b39b1dfdbbc57017b4d7c2ad2a05','profile':'PHP8.4.28 RUNPATH corrected; 512M; SQLite; CI APP_URL https://nexora.test; fresh faithful tracked checkout','command':cmd},indent=2)+'\n')
print((p.stdout+p.stderr)[-16000:]);raise SystemExit(p.returncode)
