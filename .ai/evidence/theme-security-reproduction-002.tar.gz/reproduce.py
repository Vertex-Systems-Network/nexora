from pathlib import Path
import concurrent.futures,json,os,shutil,subprocess,hashlib
root=Path('/workspace/scratch/7bc868eb9250/nexora');out=Path('/tmp/nexora-reproduction-002');out.mkdir(exist_ok=True)
env=os.environ.copy();env['PATH']='/tmp/nexora-governed-toolchain/bin:'+env['PATH']
packages=['laravel/framework:^13.42','symfony/http-foundation:~7.4.23','symfony/http-kernel:~7.4.23','symfony/mailer:~7.4.23','symfony/mime:~7.4.23','symfony/routing:~7.4.23','symfony/serializer:~7.4.23','web-auth/webauthn-lib:~5.3.13']
def work(letter):
 d=out/letter/'workspace';d.mkdir(parents=True,exist_ok=True)
 for f in ['composer.json','composer.lock','package.json','package-lock.json']:
  data=subprocess.check_output(['git','show','28bb3e11737a77c14239f4631c68818487100c55:'+f],cwd=root);(d/f).write_bytes(data)
 cmd=['composer','update',*packages,'--with-dependencies','--minimal-changes','--no-install','--no-scripts','--no-plugins','--no-progress','--no-interaction']
 result=subprocess.run(cmd,cwd=d,env=env,capture_output=True,text=True,timeout=240)
 (out/(letter+'-resolve.stdout')).write_text(result.stdout);(out/(letter+'-resolve.stderr')).write_text(result.stderr)
 if result.returncode:raise RuntimeError(letter+': '+result.stderr[-2000:])
 code='require "scripts/lib/dependency-candidate-supply-chain.php"; require "scripts/lib/dependency-toolchain.php"; $root=getcwd();$w=$argv[1];$env=NexoraBootstrapProcessEnvironment::build($root, $_ENV); echo json_encode(["supply_chain"=>nexoraRunDependencyCandidateSupplyChain($root,$w,["composer"],$env),"validation"=>nexoraValidateDependencyLockPair($root,$w."/composer.lock",$w."/package-lock.json",true),"semantic"=>nexoraDependencyLockSemanticDigests($w."/composer.lock",$w."/package-lock.json")], JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES);'
 checks=subprocess.run(['php','-r',code,str(d)],cwd=root,env=env,capture_output=True,text=True,timeout=240)
 (out/(letter+'-checks.json')).write_text(checks.stdout);(out/(letter+'-checks.stderr')).write_text(checks.stderr)
 if checks.returncode:raise RuntimeError(letter+' checks '+checks.stderr)
 x=json.loads(checks.stdout)
 assert x['supply_chain']['status']=='pass',x
 assert x['validation']['errors']==[],x
 return {'workspace':letter,'hashes':{f:hashlib.sha256((d/f).read_bytes()).hexdigest() for f in ['composer.json','composer.lock','package.json','package-lock.json']},'checks':x,'resolve_exit_code':result.returncode,'checks_exit_code':checks.returncode}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as p:results=list(p.map(work,['A','B']))
summary={'source_sha':'28bb3e11737a77c14239f4631c68818487100c55','toolchain':json.loads(Path('/tmp/nexora-governed-toolchain/identity.json').read_text()),'workspaces':results,'raw_exact_match':results[0]['hashes']==results[1]['hashes'],'semantic_exact_match':results[0]['checks']['semantic']==results[1]['checks']['semantic'],'supply_chain_exact_match':results[0]['checks']['supply_chain']['fingerprint_sha256']==results[1]['checks']['supply_chain']['fingerprint_sha256'],'prior_candidate_exact_match':hashlib.sha256(Path('/tmp/nexora-dependency-candidate/composer.lock').read_bytes()).hexdigest()==results[0]['hashes']['composer.lock'],'root_lockfiles_mutated':False,'promotion_ready':False,'remaining':['independent review','official promotion metadata/source binding','fresh full exact-head CI','target acceptance remains separate']}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['workspaces','toolchain']}))
